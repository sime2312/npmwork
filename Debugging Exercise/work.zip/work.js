const x = document.querySelector('ul').children;
console.log(x);
const allsectionelement = document.querySelector('div').children;
console.log(allsectionelement);
const current = document.querySelector(".current");
console.log(current);
const aftercurrent = current.nextElementSibling;
console.log(aftercurrent);
const beforecurrent = current.previousElementSibling;
console.log(beforecurrent);
const highlight = document.getElementsByClassName('highlight')
console.log(highlight);
const all = Array.from(document.querySelectorAll('h2')).map(s=>s.parentElement);
console.log(all);









