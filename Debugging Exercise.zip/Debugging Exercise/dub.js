
const storeOwners = [
    {name: 'Charles', stores: 1},
    {name: 'sally', stores: 1 },
    {name: 'cassandra', stores: 1 },
    {name:"Danny Shavez", stores: 1, location: "in NM"},
];

const listNumberOfStores = function () {
    let totalLocations = 0;
    for (let i = 0; i < storeOwners.length; i++) {
        totalLocations += storeOwners[i].stores;

    }

    return totalLocations;
};

let locations = listNumberOfStores();
function tellMeMyStores() {
    console.log("Hey, can you tell me how many stores you have?");
    if (locations > 0) {
        console.log("Of course, we have " + locations + " stores");
    }
}

function hasStore() {
    for (let i = 0; i < 3; i++) {
        let people = storeOwners[i];
        console.log("Yes, " + people.name + " has one");
    }
}

tellMeMyStores();
hasStore();

let man = storeOwners[3];
let mister = man.name;

let whereHeLives = man.location;
console.log("Yes, " + mister + " that lives " + whereHeLives + " owns one too.");


